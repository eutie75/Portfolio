# 🏥 MediQueue — Full Stack (PHP + MySQL)
### Hospital Ticketing Management System with Authentication & Role-Based Access

---

## 📁 Project Structure

```
MediQueue-Full/
│
├── index.php               ← Main app (requires login)
├── login.php               ← Login page
├── logout.php              ← Session logout
├── README.md               ← This file
│
├── config/
│   └── database.php        ← DB credentials & PDO connection
│
├── includes/
│   ├── auth.php            ← Login, logout, session, role checks
│   └── helpers.php         ← JSON response, ticket generation, utils
│
├── api/                    ← REST API endpoints (called by JS)
│   ├── register.php        ← POST: Register patient, generate ticket
│   ├── queue.php           ← GET/POST: Queue list + status actions
│   ├── stats.php           ← GET: Dashboard & analytics stats
│   ├── users.php           ← CRUD: User management (admin only)
│   └── departments.php     ← GET: List departments
│
├── css/
│   └── style.css           ← All styles
│
├── js/
│   └── app.js              ← Frontend logic, API calls
│
├── pages/                  ← Reserved for future standalone pages
│
└── sql/
    └── schema.sql          ← Full database schema + seed data
```

---

## ⚙️ Setup Instructions

### Requirements
- PHP 8.0 or higher
- MySQL 5.7+ or MariaDB 10.4+
- A local server: **XAMPP**, **WAMP**, **Laragon**, or **MAMP**

---

### Step 1 — Set up the database

1. Open **phpMyAdmin** (usually at `http://localhost/phpmyadmin`)
2. Click **Import**
3. Choose `sql/schema.sql` and click **Go**

This creates the `mediqueue` database with all tables and default users.

---

### Step 2 — Configure the database connection

Open `config/database.php` and update:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'mediqueue');
define('DB_USER', 'root');        // ← your MySQL username
define('DB_PASS', '');            // ← your MySQL password
```

---

### Step 3 — Place the project in your server root

| Server  | Folder to place in        | URL to open                        |
|---------|---------------------------|------------------------------------|
| XAMPP   | `C:/xampp/htdocs/`        | `http://localhost/MediQueue-Full/` |
| WAMP    | `C:/wamp64/www/`          | `http://localhost/MediQueue-Full/` |
| Laragon | `C:/laragon/www/`         | `http://mediqueue-full.test/`      |
| MAMP    | `/Applications/MAMP/htdocs/` | `http://localhost:8888/MediQueue-Full/` |

---

### Step 4 — Open in browser

Go to: `http://localhost/MediQueue-Full/`

You'll be redirected to the login page.

---

## 🔑 Default Login Credentials

All accounts use password: **`password`**

| Username   | Role                | Access Level                          |
|------------|---------------------|---------------------------------------|
| `admin`    | Administrator       | Full access — all screens + user mgmt |
| `jane`     | Receptionist        | Dashboard, Register, Queue, Depts     |
| `dr_kamau` | Doctor / Clinician  | Dashboard, Queue, Depts, Analytics    |

> ⚠️ Change all passwords immediately in production!

---

## 👥 Role Permissions

| Feature            | Admin | Receptionist | Doctor | Pharmacist |
|--------------------|:-----:|:------------:|:------:|:----------:|
| Dashboard          | ✅    | ✅           | ✅     | ✅         |
| Register Patient   | ✅    | ✅           | ✗      | ✗          |
| Queue Manager      | ✅    | ✅           | ✅     | ✅         |
| Departments        | ✅    | ✅           | ✅     | ✅         |
| Analytics          | ✅    | ✗            | ✅     | ✗          |
| User Management    | ✅    | ✗            | ✗      | ✗          |

---

## 🗄️ Key Database Tables

| Table          | Purpose                                    |
|----------------|--------------------------------------------|
| `users`        | Staff accounts with hashed passwords       |
| `roles`        | admin, receptionist, doctor, pharmacist    |
| `departments`  | 10 hospital departments                    |
| `patients`     | All registered patients & ticket info      |
| `activity_log` | Audit trail: logins, registrations, calls  |

---

## 🔌 API Endpoints

| Method | Endpoint              | Auth Required | Description                  |
|--------|-----------------------|---------------|------------------------------|
| POST   | `api/register.php`    | receptionist+ | Register patient, get ticket |
| GET    | `api/queue.php`       | any login     | Fetch live queue             |
| POST   | `api/queue.php`       | any login     | call / serve / skip / cancel |
| GET    | `api/stats.php`       | any login     | Dashboard & analytics data   |
| GET    | `api/departments.php` | any login     | List departments             |
| GET    | `api/users.php`       | admin only    | List all users               |
| POST   | `api/users.php`       | admin only    | Create user                  |
| PUT    | `api/users.php?id=N`  | admin only    | Update user                  |
| DELETE | `api/users.php?id=N`  | admin only    | Deactivate user              |

---

## 🔒 Security Features

- Passwords hashed with **bcrypt** (cost 12)
- Session-based authentication with **HttpOnly** cookies
- Role-based access control on every API endpoint
- PDO prepared statements — **SQL injection safe**
- Activity log for full **audit trail**
- Input sanitization on all user inputs

---

## 🎫 Ticket Numbering

Tickets are auto-prefixed by department initial + daily sequential count:
- `G001` → General OPD (1st patient of the day)
- `E002` → Emergency
- `PH001` → Pharmacy

Counter resets daily.

---

*MediQueue v2.0 — Built for Nairobi General Hospital*
