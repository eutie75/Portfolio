<?php
// ============================================================
// MediQueue — api/departments.php
// GET: List all active departments
// ============================================================
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
requireLogin();
header('Content-Type: application/json');
jsonResponse(true, getDepartments());
