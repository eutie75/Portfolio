<?php
// ============================================================
// MediQueue — api/queue.php
// GET:  Fetch live queue  (with filters)
// POST: Update patient status (call / serve / skip / cancel)
// ============================================================

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
header('Content-Type: application/json');

// ── GET — list queue ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $dept   = (int)($_GET['dept']   ?? 0);
    $search = clean($_GET['search'] ?? '');
    $status = clean($_GET['status'] ?? '');   // '' = all active

    $where  = ['p.status != "Served"', 'p.status != "Cancelled"'];
    $params = [];

    if ($dept) {
        $where[]  = 'p.department_id = ?';
        $params[] = $dept;
    }
    if ($search) {
        $where[]  = '(p.ticket_number LIKE ? OR p.first_name LIKE ? OR p.last_name LIKE ? OR d.name LIKE ?)';
        $like     = "%$search%";
        $params   = array_merge($params, [$like, $like, $like, $like]);
    }
    if ($status) {
        $where[]  = 'p.status = ?';
        $params[] = $status;
    }

    $sql = '
        SELECT p.id, p.ticket_number, p.first_name, p.last_name,
               p.age, p.gender, p.priority, p.status, p.complaint,
               p.created_at, p.called_at,
               d.name AS dept_name, d.color, d.bg_color,
               TIMESTAMPDIFF(MINUTE, p.created_at, NOW()) AS wait_mins,
               u.full_name AS registered_by_name
        FROM patients p
        JOIN departments d ON d.id = p.department_id
        LEFT JOIN users u  ON u.id = p.registered_by
        WHERE ' . implode(' AND ', $where) . '
        ORDER BY
            FIELD(p.priority,"Emergency","Urgent","Normal"),
            p.created_at ASC
    ';

    try {
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        jsonResponse(true, $stmt->fetchAll());
    } catch (Exception $e) {
        jsonResponse(false, null, $e->getMessage(), 500);
    }
}

// ── POST — update patient status ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data      = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $patientId = (int)($data['patient_id'] ?? 0);
    $action    = clean($data['action']     ?? '');   // call | serve | skip | cancel | call_next

    if (!$patientId && $action !== 'call_next') {
        jsonResponse(false, null, 'Patient ID required.', 422);
    }

    $userId = currentUser()['id'];
    $pdo    = db();

    try {
        switch ($action) {

            case 'call':
                requireRole(['admin','receptionist','doctor','pharmacist']);
                $pdo->prepare('UPDATE patients SET status="Called", called_by=?, called_at=NOW() WHERE id=?')
                    ->execute([$userId, $patientId]);
                logActivity($userId, 'call', $patientId, 'Patient called');
                break;

            case 'call_next':
                requireRole(['admin','receptionist','doctor','pharmacist']);
                $deptFilter = (int)($data['dept_id'] ?? 0);
                $extra      = $deptFilter ? 'AND p.department_id = ' . $deptFilter : '';
                $next = $pdo->query("
                    SELECT p.id FROM patients p
                    WHERE p.status='Waiting' $extra
                    ORDER BY FIELD(p.priority,'Emergency','Urgent','Normal'), p.created_at ASC
                    LIMIT 1
                ")->fetch();
                if (!$next) jsonResponse(false, null, 'No patients waiting.', 404);
                $pdo->prepare('UPDATE patients SET status="Called", called_by=?, called_at=NOW() WHERE id=?')
                    ->execute([$userId, $next['id']]);
                logActivity($userId, 'call', $next['id'], 'Called next patient');
                $patientId = $next['id'];
                break;

            case 'serve':
                requireRole(['admin','receptionist','doctor','pharmacist']);
                $pdo->prepare('UPDATE patients SET status="Served", served_by=?, served_at=NOW() WHERE id=?')
                    ->execute([$userId, $patientId]);
                logActivity($userId, 'serve', $patientId, 'Patient marked served');
                break;

            case 'skip':
                requireRole(['admin','receptionist']);
                $pdo->prepare('UPDATE patients SET status="Waiting", called_at=NULL WHERE id=?')
                    ->execute([$patientId]);
                logActivity($userId, 'skip', $patientId, 'Patient skipped back to waiting');
                break;

            case 'cancel':
                requireRole(['admin','receptionist']);
                $pdo->prepare('UPDATE patients SET status="Cancelled" WHERE id=?')
                    ->execute([$patientId]);
                logActivity($userId, 'cancel', $patientId, 'Patient cancelled');
                break;

            default:
                jsonResponse(false, null, 'Unknown action.', 422);
        }

        // Return updated patient row
        $stmt = $pdo->prepare('
            SELECT p.*, d.name AS dept_name, d.color, d.bg_color
            FROM patients p
            JOIN departments d ON d.id = p.department_id
            WHERE p.id = ?
        ');
        $stmt->execute([$patientId]);
        jsonResponse(true, $stmt->fetch(), 'Action completed.');

    } catch (Exception $e) {
        jsonResponse(false, null, $e->getMessage(), 500);
    }
}

jsonResponse(false, null, 'Method not allowed', 405);
