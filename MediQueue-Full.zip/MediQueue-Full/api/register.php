<?php
// ============================================================
// MediQueue — api/register.php
// POST: Register a new patient and generate ticket
// ============================================================

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireRole(['admin', 'receptionist']);
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, null, 'Method not allowed', 405);
}

$data = json_decode(file_get_contents('php://input'), true) ?: $_POST;

$firstName  = clean($data['first_name']  ?? '');
$lastName   = clean($data['last_name']   ?? '');
$deptId     = (int)($data['department_id'] ?? 0);
$priority   = clean($data['priority']    ?? 'Normal');
$age        = isset($data['age']) && $data['age'] !== '' ? (int)$data['age'] : null;
$gender     = clean($data['gender']      ?? '');
$phone      = clean($data['phone']       ?? '');
$nationalId = clean($data['national_id'] ?? '');
$complaint  = clean($data['complaint']   ?? '');

// Validate
if (!$firstName || !$lastName) {
    jsonResponse(false, null, 'First name and last name are required.', 422);
}
if (!$deptId) {
    jsonResponse(false, null, 'Please select a department.', 422);
}
if (!in_array($priority, ['Normal', 'Urgent', 'Emergency'])) {
    jsonResponse(false, null, 'Invalid priority.', 422);
}

try {
    $pdo    = db();
    $ticket = generateTicket($deptId);
    $userId = currentUser()['id'];

    $stmt = $pdo->prepare('
        INSERT INTO patients
            (ticket_number, first_name, last_name, age, gender, phone, national_id,
             department_id, priority, complaint, status, registered_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "Waiting", ?)
    ');
    $stmt->execute([$ticket, $firstName, $lastName, $age, $gender ?: null,
                    $phone ?: null, $nationalId ?: null, $deptId,
                    $priority, $complaint ?: null, $userId]);

    $patientId = (int)$pdo->lastInsertId();
    logActivity($userId, 'register', $patientId, "Registered patient $firstName $lastName — Ticket: $ticket");

    // Fetch full patient record to return
    $patient = $pdo->prepare('
        SELECT p.*, d.name AS dept_name, d.code AS dept_code, d.color, d.bg_color,
               u.full_name AS registered_by_name
        FROM patients p
        JOIN departments d ON d.id = p.department_id
        LEFT JOIN users u  ON u.id = p.registered_by
        WHERE p.id = ?
    ');
    $patient->execute([$patientId]);
    $row = $patient->fetch();

    // Ahead-of-you count
    $ahead = $pdo->prepare('
        SELECT COUNT(*) FROM patients
        WHERE department_id = ? AND status = "Waiting" AND id < ?
    ');
    $ahead->execute([$deptId, $patientId]);
    $row['ahead']     = (int)$ahead->fetchColumn();
    $row['wait_mins'] = estimateWait($deptId, $priority);

    jsonResponse(true, $row, 'Patient registered successfully.');

} catch (Exception $e) {
    jsonResponse(false, null, 'Registration failed: ' . $e->getMessage(), 500);
}
