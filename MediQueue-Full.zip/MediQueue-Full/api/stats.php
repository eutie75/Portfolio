<?php
// ============================================================
// MediQueue — api/stats.php
// GET: Dashboard stats, department counts, analytics
// ============================================================

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireLogin();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse(false, null, 'Method not allowed', 405);
}

$type = clean($_GET['type'] ?? 'dashboard');
$pdo  = db();

try {
    switch ($type) {

        // ── Main dashboard stats ──────────────────────────────
        case 'dashboard':
            $waiting = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='Waiting' AND DATE(created_at)=CURDATE()")->fetchColumn();
            $called  = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='Called'  AND DATE(created_at)=CURDATE()")->fetchColumn();
            $served  = $pdo->query("SELECT COUNT(*) FROM patients WHERE status='Served'  AND DATE(served_at)=CURDATE()")->fetchColumn();
            $emerg   = $pdo->query("SELECT COUNT(*) FROM patients WHERE priority='Emergency' AND status IN('Waiting','Called') AND DATE(created_at)=CURDATE()")->fetchColumn();
            $total   = $pdo->query("SELECT COUNT(*) FROM patients WHERE DATE(created_at)=CURDATE()")->fetchColumn();

            // Average wait for served patients today
            $avgWait = $pdo->query("
                SELECT COALESCE(AVG(TIMESTAMPDIFF(MINUTE, created_at, served_at)),0)
                FROM patients WHERE status='Served' AND DATE(served_at)=CURDATE()
            ")->fetchColumn();

            // Dept breakdown
            $deptStmt = $pdo->query("
                SELECT d.id, d.name, d.color, d.bg_color, d.code,
                       SUM(CASE WHEN p.status='Waiting' THEN 1 ELSE 0 END) AS waiting,
                       SUM(CASE WHEN p.status='Called'  THEN 1 ELSE 0 END) AS called,
                       SUM(CASE WHEN p.status='Served' AND DATE(p.served_at)=CURDATE() THEN 1 ELSE 0 END) AS served,
                       SUM(CASE WHEN p.priority!='Normal' AND p.status IN('Waiting','Called') THEN 1 ELSE 0 END) AS priority_count
                FROM departments d
                LEFT JOIN patients p ON p.department_id = d.id AND DATE(p.created_at) = CURDATE()
                WHERE d.is_active=1
                GROUP BY d.id
                ORDER BY d.name
            ");

            // Recent 10 patients
            $recent = $pdo->query("
                SELECT p.id, p.ticket_number, p.first_name, p.last_name,
                       p.priority, p.status, p.created_at,
                       d.name AS dept_name, d.color
                FROM patients p
                JOIN departments d ON d.id = p.department_id
                WHERE DATE(p.created_at) = CURDATE()
                ORDER BY p.created_at DESC
                LIMIT 10
            ")->fetchAll();

            // Currently called
            $calling = $pdo->query("
                SELECT p.id, p.ticket_number, p.first_name, p.last_name,
                       p.priority, d.name AS dept_name
                FROM patients p
                JOIN departments d ON d.id = p.department_id
                WHERE p.status='Called'
                ORDER BY p.called_at DESC LIMIT 1
            ")->fetch();

            // Next in queue
            $nextUp = $pdo->query("
                SELECT p.id, p.ticket_number, p.first_name, p.last_name
                FROM patients p
                WHERE p.status='Waiting'
                ORDER BY FIELD(p.priority,'Emergency','Urgent','Normal'), p.created_at ASC
                LIMIT 1
            ")->fetch();

            jsonResponse(true, [
                'waiting'    => (int)$waiting,
                'called'     => (int)$called,
                'served'     => (int)$served,
                'emergency'  => (int)$emerg,
                'total'      => (int)$total,
                'avg_wait'   => round((float)$avgWait),
                'departments'=> $deptStmt->fetchAll(),
                'recent'     => $recent,
                'calling'    => $calling ?: null,
                'next_up'    => $nextUp  ?: null,
            ]);
            break;

        // ── Analytics ─────────────────────────────────────────
        case 'analytics':
            // Hourly registrations today
            $hourly = $pdo->query("
                SELECT HOUR(created_at) AS hour, COUNT(*) AS count
                FROM patients
                WHERE DATE(created_at) = CURDATE()
                GROUP BY HOUR(created_at)
                ORDER BY hour
            ")->fetchAll();

            // Priority distribution today
            $priorities = $pdo->query("
                SELECT priority, COUNT(*) AS count
                FROM patients WHERE DATE(created_at) = CURDATE()
                GROUP BY priority
            ")->fetchAll();

            // Last 50 served
            $log = $pdo->query("
                SELECT p.ticket_number, p.first_name, p.last_name,
                       p.priority, p.status, p.created_at, p.served_at,
                       d.name AS dept_name, d.color, d.bg_color,
                       TIMESTAMPDIFF(MINUTE, p.created_at, p.served_at) AS service_mins
                FROM patients p
                JOIN departments d ON d.id = p.department_id
                WHERE p.status='Served' AND DATE(p.served_at) = CURDATE()
                ORDER BY p.served_at DESC
                LIMIT 50
            ")->fetchAll();

            // Weekly registrations (last 7 days)
            $weekly = $pdo->query("
                SELECT DATE(created_at) AS date, COUNT(*) AS count
                FROM patients
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
                GROUP BY DATE(created_at)
                ORDER BY date
            ")->fetchAll();

            jsonResponse(true, [
                'hourly'     => $hourly,
                'priorities' => $priorities,
                'log'        => $log,
                'weekly'     => $weekly,
            ]);
            break;

        default:
            jsonResponse(false, null, 'Unknown stat type', 422);
    }

} catch (Exception $e) {
    jsonResponse(false, null, $e->getMessage(), 500);
}
