<?php
// ============================================================
// MediQueue — api/users.php
// Full user CRUD — admin only
// ============================================================

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

requireRole(['admin']);
header('Content-Type: application/json');

$pdo    = db();
$method = $_SERVER['REQUEST_METHOD'];
$userId = (int)($_GET['id'] ?? 0);

// ── GET — list users ──────────────────────────────────────────
if ($method === 'GET' && !$userId) {
    $users = $pdo->query('
        SELECT u.id, u.full_name, u.email, u.username, u.department,
               u.is_active, u.last_login, u.created_at, r.name AS role, r.label AS role_label
        FROM users u JOIN roles r ON r.id = u.role_id
        ORDER BY u.created_at DESC
    ')->fetchAll();
    jsonResponse(true, $users);
}

// ── GET — single user ─────────────────────────────────────────
if ($method === 'GET' && $userId) {
    $stmt = $pdo->prepare('
        SELECT u.id, u.full_name, u.email, u.username, u.department,
               u.is_active, u.last_login, u.role_id, r.name AS role
        FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?
    ');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    if (!$user) jsonResponse(false, null, 'User not found.', 404);
    jsonResponse(true, $user);
}

$data = json_decode(file_get_contents('php://input'), true) ?: $_POST;

// ── POST — create user ────────────────────────────────────────
if ($method === 'POST') {
    $fullName = clean($data['full_name'] ?? '');
    $email    = clean($data['email']     ?? '');
    $username = clean($data['username']  ?? '');
    $password = $data['password']        ?? '';
    $roleId   = (int)($data['role_id']   ?? 2);
    $dept     = clean($data['department']?? '') ?: null;

    if (!$fullName || !$email || !$username || !$password) {
        jsonResponse(false, null, 'Full name, email, username and password are required.', 422);
    }
    if (strlen($password) < 8) {
        jsonResponse(false, null, 'Password must be at least 8 characters.', 422);
    }

    try {
        $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
        $pdo->prepare('
            INSERT INTO users (full_name, email, username, password_hash, role_id, department)
            VALUES (?, ?, ?, ?, ?, ?)
        ')->execute([$fullName, $email, $username, $hash, $roleId, $dept]);
        $newId = (int)$pdo->lastInsertId();
        logActivity(currentUser()['id'], 'create_user', null, "Created user: $username");
        jsonResponse(true, ['id' => $newId], 'User created successfully.');
    } catch (PDOException $e) {
        if (str_contains($e->getMessage(), 'Duplicate')) {
            jsonResponse(false, null, 'Username or email already exists.', 422);
        }
        jsonResponse(false, null, $e->getMessage(), 500);
    }
}

// ── PUT — update user ─────────────────────────────────────────
if ($method === 'PUT') {
    if (!$userId) jsonResponse(false, null, 'User ID required.', 422);

    $fullName = clean($data['full_name'] ?? '');
    $email    = clean($data['email']     ?? '');
    $roleId   = (int)($data['role_id']   ?? 0);
    $dept     = clean($data['department']?? '') ?: null;
    $isActive = isset($data['is_active']) ? (int)$data['is_active'] : 1;

    $fields = [];
    $params = [];
    if ($fullName) { $fields[] = 'full_name=?'; $params[] = $fullName; }
    if ($email)    { $fields[] = 'email=?';     $params[] = $email; }
    if ($roleId)   { $fields[] = 'role_id=?';   $params[] = $roleId; }
    $fields[]  = 'department=?';  $params[] = $dept;
    $fields[]  = 'is_active=?';   $params[] = $isActive;

    if (!empty($data['password']) && strlen($data['password']) >= 8) {
        $fields[] = 'password_hash=?';
        $params[] = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]);
    }
    $params[] = $userId;

    $pdo->prepare('UPDATE users SET ' . implode(',', $fields) . ' WHERE id=?')->execute($params);
    logActivity(currentUser()['id'], 'update_user', null, "Updated user ID: $userId");
    jsonResponse(true, null, 'User updated successfully.');
}

// ── DELETE — deactivate user ──────────────────────────────────
if ($method === 'DELETE') {
    if (!$userId) jsonResponse(false, null, 'User ID required.', 422);
    if ($userId === currentUser()['id']) jsonResponse(false, null, 'Cannot deactivate yourself.', 422);
    $pdo->prepare('UPDATE users SET is_active=0 WHERE id=?')->execute([$userId]);
    logActivity(currentUser()['id'], 'deactivate_user', null, "Deactivated user ID: $userId");
    jsonResponse(true, null, 'User deactivated.');
}

jsonResponse(false, null, 'Method not allowed', 405);
