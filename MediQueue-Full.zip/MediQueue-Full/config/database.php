<?php
// ============================================================
// MediQueue — config/database.php
// Database connection settings — edit before deployment
// ============================================================

define('DB_HOST',     'localhost');
define('DB_NAME',     'mediqueue');
define('DB_USER',     'root');        // change to your MySQL user
define('DB_PASS',     '');            // change to your MySQL password
define('DB_CHARSET',  'utf8mb4');

// App settings
define('APP_NAME',    'MediQueue');
define('APP_VERSION', '2.0');
define('HOSPITAL',    'Nairobi General Hospital');
define('SESSION_LIFETIME', 3600 * 8); // 8 hours

/**
 * Returns a PDO connection (singleton).
 */
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}
