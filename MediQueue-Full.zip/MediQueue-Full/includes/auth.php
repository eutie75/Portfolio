<?php
// ============================================================
// MediQueue — includes/auth.php
// Session management, login/logout, role-based access control
// ============================================================

require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path'     => '/',
        'secure'   => false,      // set true in production over HTTPS
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

// ── Check if a user is logged in ─────────────────────────────
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

// ── Require login — redirect to login page if not ────────────
function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: /login.php');
        exit;
    }
}

// ── Require a specific role (or array of roles) ───────────────
function requireRole(array $roles): void {
    requireLogin();
    if (!in_array($_SESSION['role'], $roles)) {
        http_response_code(403);
        die(json_encode(['success' => false, 'message' => 'Access denied. Insufficient permissions.']));
    }
}

// ── Get current user info from session ────────────────────────
function currentUser(): array {
    return [
        'id'        => $_SESSION['user_id']   ?? null,
        'username'  => $_SESSION['username']  ?? null,
        'full_name' => $_SESSION['full_name'] ?? null,
        'role'      => $_SESSION['role']      ?? null,
        'dept'      => $_SESSION['department'] ?? null,
    ];
}

// ── Login — returns user array on success or false ────────────
function login(string $username, string $password): array|false {
    $pdo  = db();
    $stmt = $pdo->prepare('
        SELECT u.*, r.name AS role_name
        FROM users u
        JOIN roles r ON r.id = u.role_id
        WHERE (u.username = ? OR u.email = ?)
          AND u.is_active = 1
        LIMIT 1
    ');
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        return false;
    }

    // Populate session
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['username']   = $user['username'];
    $_SESSION['full_name']  = $user['full_name'];
    $_SESSION['role']       = $user['role_name'];
    $_SESSION['department'] = $user['department'];

    // Update last login
    $pdo->prepare('UPDATE users SET last_login = NOW() WHERE id = ?')->execute([$user['id']]);

    // Log it
    logActivity($user['id'], 'login', null, 'User logged in');

    return $user;
}

// ── Logout ────────────────────────────────────────────────────
function logout(): void {
    if (isLoggedIn()) {
        logActivity($_SESSION['user_id'], 'logout', null, 'User logged out');
    }
    session_unset();
    session_destroy();
}

// ── Log an activity ───────────────────────────────────────────
function logActivity(?int $userId, string $action, ?int $patientId = null, ?string $details = null): void {
    try {
        db()->prepare('
            INSERT INTO activity_log (user_id, action, patient_id, details, ip_address)
            VALUES (?, ?, ?, ?, ?)
        ')->execute([$userId, $action, $patientId, $details, $_SERVER['REMOTE_ADDR'] ?? null]);
    } catch (Exception $e) {
        // Non-fatal — swallow silently
    }
}

// ── Role permission map ───────────────────────────────────────
const PERMISSIONS = [
    'admin'        => ['dashboard','register','queue','departments','analytics','users','reports'],
    'receptionist' => ['dashboard','register','queue','departments'],
    'doctor'       => ['dashboard','queue','departments','analytics'],
    'pharmacist'   => ['dashboard','queue','departments'],
];

function can(string $action): bool {
    $role = $_SESSION['role'] ?? '';
    return in_array($action, PERMISSIONS[$role] ?? []);
}
