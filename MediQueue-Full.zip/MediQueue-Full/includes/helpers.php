<?php
// ============================================================
// MediQueue — includes/helpers.php
// Shared utility functions
// ============================================================

require_once __DIR__ . '/../config/database.php';

// ── JSON API response ─────────────────────────────────────────
function jsonResponse(bool $success, mixed $data = null, string $message = '', int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data'    => $data,
    ]);
    exit;
}

// ── Sanitize input ────────────────────────────────────────────
function clean(?string $val): string {
    return trim(htmlspecialchars($val ?? '', ENT_QUOTES, 'UTF-8'));
}

// ── Generate next ticket number for a department ──────────────
function generateTicket(int $deptId): string {
    $pdo  = db();
    $stmt = $pdo->prepare('SELECT code FROM departments WHERE id = ? LIMIT 1');
    $stmt->execute([$deptId]);
    $dept = $stmt->fetch();
    if (!$dept) throw new RuntimeException('Department not found');

    // Count today's tickets for this dept
    $count = $pdo->prepare('
        SELECT COUNT(*) FROM patients
        WHERE department_id = ?
          AND DATE(created_at) = CURDATE()
    ');
    $count->execute([$deptId]);
    $n = (int)$count->fetchColumn() + 1;

    return $dept['code'] . str_pad($n, 3, '0', STR_PAD_LEFT);
}

// ── Fetch all departments ─────────────────────────────────────
function getDepartments(): array {
    return db()->query('SELECT * FROM departments WHERE is_active = 1 ORDER BY name')->fetchAll();
}

// ── Estimated wait time (minutes) ────────────────────────────
function estimateWait(int $deptId, string $priority): int {
    $pdo  = db();
    $stmt = $pdo->prepare('
        SELECT COUNT(*) FROM patients
        WHERE department_id = ? AND status = "Waiting"
    ');
    $stmt->execute([$deptId]);
    $ahead = (int)$stmt->fetchColumn();
    $base  = match($priority) { 'Emergency' => 0, 'Urgent' => $ahead * 4, default => $ahead * 7 };
    return $base;
}
