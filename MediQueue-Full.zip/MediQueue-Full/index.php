<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>MediQueue — Dashboard</title>
  <link rel="stylesheet" href="css/style.css"/>
</head>
<body>
<?php
require_once 'includes/auth.php';
requireLogin();
$user = currentUser();
?>

<div class="app">

  <!-- ── Sidebar ── -->
  <div class="sidebar">
    <div class="sidebar-logo">
      <h1>🏥 MediQueue</h1>
      <span>Hospital Management System</span>
    </div>
    <nav class="nav">
      <div class="nav-item active" onclick="switchScreen('dashboard',this)">
        <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1" stroke-width="2"/><rect x="14" y="3" width="7" height="7" rx="1" stroke-width="2"/><rect x="3" y="14" width="7" height="7" rx="1" stroke-width="2"/><rect x="14" y="14" width="7" height="7" rx="1" stroke-width="2"/></svg>
        <span>Dashboard</span>
      </div>
      <?php if (can('register')): ?>
      <div class="nav-item" onclick="switchScreen('register',this)">
        <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m-8-8h16" stroke-width="2" stroke-linecap="round"/></svg>
        <span>Register Patient</span>
      </div>
      <?php endif; ?>
      <div class="nav-item" onclick="switchScreen('queue',this)">
        <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" stroke-width="2" stroke-linecap="round"/></svg>
        <span>Queue Manager</span>
      </div>
      <div class="nav-item" onclick="switchScreen('departments',this)">
        <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" stroke-width="2"/><polyline points="9 22 9 12 15 12 15 22" stroke-width="2"/></svg>
        <span>Departments</span>
      </div>
      <?php if (can('analytics')): ?>
      <div class="nav-item" onclick="switchScreen('analytics',this)">
        <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M18 20V10M12 20V4M6 20v-6" stroke-width="2" stroke-linecap="round"/></svg>
        <span>Analytics</span>
      </div>
      <?php endif; ?>
      <?php if (can('users')): ?>
      <div class="nav-item" onclick="switchScreen('users',this)">
        <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" stroke-width="2"/><circle cx="9" cy="7" r="4" stroke-width="2"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" stroke-width="2"/></svg>
        <span>Users</span>
      </div>
      <?php endif; ?>
    </nav>
    <div class="sidebar-user">
      <div class="user-avatar"><?= strtoupper(substr($user['full_name'], 0, 2)) ?></div>
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
        <div class="user-role"><?= htmlspecialchars(ucfirst($user['role'])) ?></div>
      </div>
      <a href="logout.php" class="logout-btn" title="Sign out">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" stroke-width="2" stroke-linecap="round"/></svg>
      </a>
    </div>
  </div>

  <!-- ── Main ── -->
  <div class="main">
    <div class="topbar">
      <h2 id="page-title">Dashboard Overview</h2>
      <div class="topbar-right">
        <span class="clock" id="clock">--:--:--</span>
        <span class="badge badge-green">● Online</span>
      </div>
    </div>

    <div class="content">

      <!-- DASHBOARD -->
      <div id="screen-dashboard" class="screen active">
        <div class="stats-row">
          <div class="stat-card green"><div class="stat-label">Waiting Now</div><div class="stat-val" id="stat-waiting">—</div><div class="stat-sub">Across all departments</div></div>
          <div class="stat-card orange"><div class="stat-label">Served Today</div><div class="stat-val" id="stat-served">—</div><div class="stat-sub">Completed consultations</div></div>
          <div class="stat-card blue"><div class="stat-label">Avg Wait Time</div><div class="stat-val" id="stat-wait">—</div><div class="stat-sub">Minutes per patient</div></div>
          <div class="stat-card red"><div class="stat-label">Emergency</div><div class="stat-val" id="stat-emergency">—</div><div class="stat-sub">High priority tickets</div></div>
        </div>
        <div class="panels">
          <div class="panel">
            <div class="panel-head"><h3>Recent Activity</h3><span class="badge badge-gray" id="recent-count">—</span></div>
            <div class="panel-body" style="padding:0;"><div id="recent-list"><div class="empty-state"><div class="ei">📋</div><p>Loading...</p></div></div></div>
          </div>
          <div class="panel">
            <div class="panel-head"><h3>Now Calling</h3><button class="btn btn-sm btn-outline" onclick="callNext()">Call Next ›</button></div>
            <div class="panel-body" style="text-align:center;padding:28px 16px;">
              <div style="font-size:12px;color:var(--text-muted);margin-bottom:8px;">CURRENT TICKET</div>
              <div id="calling-num" style="font-family:var(--mono);font-size:56px;font-weight:700;color:var(--primary);line-height:1;">—</div>
              <div id="calling-dept" style="font-size:13px;color:var(--text-muted);margin-top:6px;"></div>
              <div id="calling-name" style="font-size:15px;font-weight:500;margin-top:8px;"></div>
              <div style="margin-top:16px;border-top:1px solid var(--border);padding-top:14px;">
                <div style="font-size:12px;color:var(--text-muted);margin-bottom:6px;">NEXT IN QUEUE</div>
                <div id="next-queue" style="font-size:13px;color:var(--text-muted);">—</div>
              </div>
            </div>
          </div>
          <div class="panel panel-full">
            <div class="panel-head"><h3>Department Load</h3></div>
            <div class="panel-body"><div class="dept-grid" id="dept-overview"></div></div>
          </div>
        </div>
      </div>

      <!-- REGISTER -->
      <?php if (can('register')): ?>
      <div id="screen-register" class="screen">
        <div class="panels">
          <div class="panel">
            <div class="panel-head"><h3>New Patient Registration</h3></div>
            <div class="panel-body">
              <div class="form-grid">
                <div class="form-group"><label>First Name *</label><input type="text" id="f-fname" placeholder="e.g. Amina"></div>
                <div class="form-group"><label>Last Name *</label><input type="text" id="f-lname" placeholder="e.g. Wanjiru"></div>
                <div class="form-group"><label>Age</label><input type="number" id="f-age" placeholder="e.g. 34" min="0" max="120"></div>
                <div class="form-group">
                  <label>Gender</label>
                  <select id="f-gender"><option value="">Select...</option><option>Male</option><option>Female</option><option>Other</option><option>Prefer not to say</option></select>
                </div>
                <div class="form-group"><label>Phone</label><input type="tel" id="f-phone" placeholder="+254 7XX XXX XXX"></div>
                <div class="form-group"><label>National ID</label><input type="text" id="f-id" placeholder="e.g. 12345678"></div>
                <div class="form-group full">
                  <label>Department *</label>
                  <select id="f-dept"><option value="">Choose department...</option></select>
                </div>
                <div class="form-group full">
                  <label>Priority Level *</label>
                  <div class="priority-select">
                    <div class="priority-opt" data-val="Normal"    onclick="selectPriority(this,'Normal')"><span class="dot dot-green"></span>Normal</div>
                    <div class="priority-opt" data-val="Urgent"    onclick="selectPriority(this,'Urgent')"><span class="dot dot-orange"></span>Urgent</div>
                    <div class="priority-opt" data-val="Emergency" onclick="selectPriority(this,'Emergency')"><span class="dot dot-red"></span>Emergency</div>
                  </div>
                </div>
                <div class="form-group full"><label>Chief Complaint</label><textarea id="f-complaint" placeholder="Briefly describe the patient's reason for visit..."></textarea></div>
              </div>
              <div style="margin-top:16px;display:flex;gap:10px;">
                <button class="btn btn-primary" onclick="registerPatient()" style="flex:1;">Generate Queue Ticket</button>
                <button class="btn btn-outline" onclick="clearForm()">Clear</button>
              </div>
            </div>
          </div>
          <div class="panel">
            <div class="panel-head"><h3>Quick Stats</h3></div>
            <div class="panel-body">
              <div style="padding:12px;background:var(--primary-light);border-radius:var(--radius-sm);margin-bottom:14px;">
                <div style="font-size:11px;color:var(--primary);font-weight:600;text-transform:uppercase;">Total Registered Today</div>
                <div style="font-size:28px;font-weight:700;color:var(--primary);margin-top:4px;" id="reg-total-count">—</div>
              </div>
              <div id="dept-reg-breakdown" style="display:grid;gap:6px;"></div>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>

      <!-- QUEUE -->
      <div id="screen-queue" class="screen">
        <div class="panel panel-full">
          <div class="panel-head">
            <h3>Live Queue</h3>
            <div style="display:flex;gap:8px;align-items:center;">
              <select id="queue-dept-filter" onchange="loadQueue()" style="font-size:12.5px;padding:5px 10px;width:auto;"><option value="">All Departments</option></select>
              <button class="btn btn-sm btn-primary" onclick="callNext()">▶ Call Next</button>
            </div>
          </div>
          <div class="panel-body" style="padding:0;">
            <div style="padding:12px 18px;border-bottom:1px solid var(--border);">
              <input type="text" id="queue-search" placeholder="Search ticket, name or department..." oninput="loadQueue()" style="max-width:380px;">
            </div>
            <div class="scroll-x">
              <table class="queue-table w-full">
                <thead><tr><th>Ticket</th><th>Patient</th><th>Department</th><th>Priority</th><th>Wait</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody id="queue-tbody"></tbody>
              </table>
              <div id="queue-empty" class="empty-state" style="display:none;"><div class="ei">🎉</div><p>Queue is empty</p></div>
            </div>
          </div>
        </div>
      </div>

      <!-- DEPARTMENTS -->
      <div id="screen-departments" class="screen">
        <div class="panel panel-full">
          <div class="panel-head"><h3>Department Status</h3><span style="font-size:12px;color:var(--text-muted);">Live capacity</span></div>
          <div class="panel-body"><div class="dept-grid" id="dept-detail-grid"></div></div>
        </div>
      </div>

      <!-- ANALYTICS -->
      <?php if (can('analytics')): ?>
      <div id="screen-analytics" class="screen">
        <div class="stats-row">
          <div class="stat-card green"><div class="stat-label">Registered Today</div><div class="stat-val" id="an-reg">—</div><div class="stat-sub">Total patients</div></div>
          <div class="stat-card blue"><div class="stat-label">Completion Rate</div><div class="stat-val" id="an-comp">—</div><div class="stat-sub">Served vs registered</div></div>
          <div class="stat-card orange"><div class="stat-label">Avg Service Time</div><div class="stat-val" id="an-avg">—</div><div class="stat-sub">Minutes per patient</div></div>
          <div class="stat-card red"><div class="stat-label">Emergency Cases</div><div class="stat-val" id="an-emerg">—</div><div class="stat-sub">High priority today</div></div>
        </div>
        <div class="panels">
          <div class="panel">
            <div class="panel-head"><h3>Hourly Registrations</h3></div>
            <div class="panel-body"><div class="bar-chart" id="hourly-chart"></div><div style="display:flex;gap:8px;margin-top:8px;" id="hourly-labels"></div></div>
          </div>
          <div class="panel">
            <div class="panel-head"><h3>Priority Distribution</h3></div>
            <div class="panel-body" id="priority-dist"><div class="empty-state"><div class="ei">📊</div><p>Loading...</p></div></div>
          </div>
          <div class="panel panel-full">
            <div class="panel-head"><h3>Service Log</h3></div>
            <div class="panel-body" style="padding:0;">
              <div class="scroll-x">
                <table class="queue-table w-full">
                  <thead><tr><th>Ticket</th><th>Name</th><th>Department</th><th>Priority</th><th>Registered</th><th>Service Time</th><th>Status</th></tr></thead>
                  <tbody id="completed-log"></tbody>
                </table>
                <div id="log-empty" class="empty-state"><div class="ei">📜</div><p>No completed services yet today</p></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>

      <!-- USERS (admin only) -->
      <?php if (can('users')): ?>
      <div id="screen-users" class="screen">
        <div class="panel panel-full">
          <div class="panel-head">
            <h3>User Management</h3>
            <button class="btn btn-sm btn-primary" onclick="openUserModal()">+ Add User</button>
          </div>
          <div class="panel-body" style="padding:0;">
            <div class="scroll-x">
              <table class="queue-table w-full">
                <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Department</th><th>Status</th><th>Last Login</th><th>Actions</th></tr></thead>
                <tbody id="users-tbody"></tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- User Modal -->
      <div id="user-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:100;align-items:center;justify-content:center;">
        <div style="background:#fff;border-radius:14px;padding:28px;width:480px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,0.2);">
          <h3 style="margin-bottom:18px;" id="user-modal-title">Add User</h3>
          <div class="form-grid">
            <div class="form-group full"><label>Full Name *</label><input type="text" id="um-name" placeholder="e.g. Dr. Jane Otieno"></div>
            <div class="form-group"><label>Username *</label><input type="text" id="um-username" placeholder="e.g. dr_jane"></div>
            <div class="form-group"><label>Email *</label><input type="email" id="um-email" placeholder="jane@hospital.local"></div>
            <div class="form-group"><label>Password *</label><input type="password" id="um-password" placeholder="Min 8 characters"></div>
            <div class="form-group">
              <label>Role *</label>
              <select id="um-role">
                <option value="2">Receptionist</option>
                <option value="3">Doctor / Clinician</option>
                <option value="4">Pharmacist / Lab Tech</option>
                <option value="1">Administrator</option>
              </select>
            </div>
            <div class="form-group"><label>Department (optional)</label><select id="um-dept"><option value="">— None —</option></select></div>
          </div>
          <div style="display:flex;gap:10px;margin-top:18px;">
            <button class="btn btn-primary" onclick="saveUser()" style="flex:1;">Save User</button>
            <button class="btn btn-outline" onclick="closeUserModal()">Cancel</button>
          </div>
        </div>
      </div>
      <?php endif; ?>

    </div><!-- /content -->
  </div><!-- /main -->
</div><!-- /app -->

<!-- Ticket Modal -->
<div class="ticket-modal" id="ticket-modal" style="display:none;" onclick="if(event.target===this)closeTicket()">
  <div class="ticket-card">
    <div class="ticket-hosp"><?= HOSPITAL ?></div>
    <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:4px;">Queue Ticket</div>
    <div class="ticket-big" id="t-num">—</div>
    <div><span class="ticket-dept-label" id="t-dept-badge" style="background:var(--primary);color:#fff;"></span></div>
    <div style="text-align:left;border-top:1px dashed var(--border);padding-top:10px;margin-top:4px;">
      <div class="ticket-row"><span>Patient</span><span id="t-name">—</span></div>
      <div class="ticket-row"><span>Department</span><span id="t-dept">—</span></div>
      <div class="ticket-row"><span>Priority</span><span id="t-priority">—</span></div>
      <div class="ticket-row"><span>Ahead of you</span><span id="t-ahead">—</span></div>
      <div class="ticket-row"><span>Est. wait</span><span id="t-wait">—</span></div>
      <div class="ticket-row"><span>Time</span><span id="t-time">—</span></div>
    </div>
    <div class="ticket-footer">Please wait until your number is called. Thank you for your patience.</div>
    <button class="btn btn-primary" style="width:100%;margin-top:16px;justify-content:center;" onclick="closeTicket()">✓ Done</button>
  </div>
</div>

<div class="notif" id="notif"></div>

<script src="js/app.js"></script>
</body>
</html>
