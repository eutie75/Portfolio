/* ============================================================
   MediQueue — js/app.js
   Frontend logic — calls PHP API endpoints
   ============================================================ */

// ── State ──────────────────────────────────────────────────────
let selectedPriority = 'Normal';
let departments      = [];
let editingUserId    = null;
let refreshTimer     = null;

// ── Boot ───────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadDepartments().then(() => {
    loadDashboard();
    setInterval(updateClock, 1000);
    updateClock();
    setInterval(loadDashboard, 30000); // auto-refresh every 30s
  });
});

// ── Clock ──────────────────────────────────────────────────────
function updateClock() {
  const el = document.getElementById('clock');
  if (el) el.textContent = new Date().toLocaleTimeString('en-KE', {hour:'2-digit',minute:'2-digit',second:'2-digit'});
}

// ── Screen switcher ────────────────────────────────────────────
function switchScreen(name, navEl) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const scr = document.getElementById('screen-' + name);
  if (scr) scr.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  if (navEl) navEl.classList.add('active');
  const titles = {
    dashboard:'Dashboard Overview', register:'Register Patient',
    queue:'Queue Manager', departments:'Departments',
    analytics:'Analytics', users:'User Management'
  };
  setText('page-title', titles[name] || name);
  if (name === 'dashboard')   loadDashboard();
  if (name === 'queue')       loadQueue();
  if (name === 'departments') loadDepts();
  if (name === 'analytics')   loadAnalytics();
  if (name === 'users')       loadUsers();
}

// ── API helper ─────────────────────────────────────────────────
async function api(url, options = {}) {
  try {
    const res  = await fetch(url, { headers: {'Content-Type':'application/json'}, ...options });
    const json = await res.json();
    if (!json.success) throw new Error(json.message || 'Request failed');
    return json.data;
  } catch (e) {
    showNotif(e.message, 'error');
    throw e;
  }
}

// ── Load Departments (cached) ──────────────────────────────────
async function loadDepartments() {
  try {
    departments = await api('api/departments.php');
    // Populate dept dropdowns
    ['f-dept','queue-dept-filter','um-dept'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      const isFilter = id === 'queue-dept-filter';
      const isUser   = id === 'um-dept';
      if (isFilter) el.innerHTML = '<option value="">All Departments</option>';
      else if (isUser) el.innerHTML = '<option value="">— None —</option>';
      else el.innerHTML = '<option value="">Choose department...</option>';
      departments.forEach(d => {
        const opt = document.createElement('option');
        opt.value       = d.id;
        opt.textContent = d.name;
        el.appendChild(opt);
      });
    });
  } catch (e) { /* handled */ }
}

// ── Dashboard ──────────────────────────────────────────────────
async function loadDashboard() {
  try {
    const data = await api('api/stats.php?type=dashboard');

    setText('stat-waiting',   data.waiting);
    setText('stat-served',    data.served);
    setText('stat-wait',      Math.round(data.avg_wait) + 'm');
    setText('stat-emergency', data.emergency);
    setText('recent-count',   data.total + ' tickets');
    setText('reg-total-count',data.total);

    // Now calling
    if (data.calling) {
      setText('calling-num',  data.calling.ticket_number);
      setText('calling-dept', data.calling.dept_name);
      setText('calling-name', data.calling.first_name + ' ' + data.calling.last_name);
    } else {
      setText('calling-num',  '—');
      setText('calling-dept', '');
      setText('calling-name', '');
    }
    setText('next-queue', data.next_up
      ? data.next_up.ticket_number + ' — ' + data.next_up.first_name + ' ' + data.next_up.last_name
      : '— No more waiting —');

    // Recent list
    const rl = document.getElementById('recent-list');
    if (rl) {
      if (!data.recent.length) {
        rl.innerHTML = emptyState('📋', 'No patients registered today');
      } else {
        rl.innerHTML = data.recent.map(p => `
          <div style="display:flex;align-items:center;gap:12px;padding:10px 18px;border-bottom:1px solid #f0f4f2;">
            <span class="ticket-num">${p.ticket_number}</span>
            <div style="flex:1;">
              <div style="font-size:13.5px;font-weight:500;">${p.first_name} ${p.last_name}</div>
              <div style="font-size:11.5px;color:var(--text-muted);">${p.dept_name} · ${fmtTime(p.created_at)}</div>
            </div>
            ${priorityBadge(p.priority)}
            ${statusBadge(p.status)}
          </div>`).join('');
      }
    }

    // Dept overview
    renderDeptCards(data.departments, 'dept-overview', false);
    renderDeptCards(data.departments, 'dept-detail-grid', true);
    renderRegBreakdown(data.departments);

  } catch(e) { /* handled */ }
}

// ── Queue ──────────────────────────────────────────────────────
async function loadQueue() {
  const dept   = document.getElementById('queue-dept-filter')?.value || '';
  const search = document.getElementById('queue-search')?.value || '';
  const params = new URLSearchParams({ dept, search });
  try {
    const list  = await api('api/queue.php?' + params);
    const tbody = document.getElementById('queue-tbody');
    const empty = document.getElementById('queue-empty');
    if (!tbody) return;
    if (!list.length) { tbody.innerHTML=''; empty.style.display='block'; return; }
    empty.style.display = 'none';
    tbody.innerHTML = list.map(p => `
      <tr>
        <td><span class="ticket-num">${p.ticket_number}</span></td>
        <td>
          <div style="font-weight:500;">${p.first_name} ${p.last_name}</div>
          <div style="font-size:11.5px;color:var(--text-muted);">${p.age || ''} ${p.gender || ''}</div>
        </td>
        <td><span class="dept-tag" style="background:${p.bg_color};color:${p.color}">${p.dept_name}</span></td>
        <td>${priorityBadge(p.priority)}</td>
        <td style="font-family:var(--mono);font-size:13px;color:var(--text-muted);">${p.wait_mins}m</td>
        <td>${statusBadge(p.status)}</td>
        <td>
          <button class="action-btn call" onclick="queueAction(${p.id},'call')">Call</button>
          <button class="action-btn done" onclick="queueAction(${p.id},'serve')">Done</button>
          <button class="action-btn skip" onclick="queueAction(${p.id},'skip')">Skip</button>
        </td>
      </tr>`).join('');
  } catch(e) { /* handled */ }
}

async function queueAction(patientId, action) {
  try {
    await api('api/queue.php', {
      method: 'POST',
      body: JSON.stringify({ patient_id: patientId, action })
    });
    showNotif(action === 'call' ? '📢 Patient called' : action === 'serve' ? '✓ Marked as served' : '↺ Moved to waiting');
    loadQueue();
    loadDashboard();
  } catch(e) { /* handled */ }
}

async function callNext() {
  try {
    await api('api/queue.php', { method:'POST', body: JSON.stringify({ action:'call_next' }) });
    showNotif('📢 Next patient called');
    loadDashboard();
    loadQueue();
  } catch(e) { /* handled */ }
}

// ── Departments ────────────────────────────────────────────────
async function loadDepts() {
  const data = await api('api/stats.php?type=dashboard');
  renderDeptCards(data.departments, 'dept-detail-grid', true);
}

function renderDeptCards(depts, containerId, detailed) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const max = Math.max(...depts.map(d => +d.waiting || 0), 1);
  el.innerHTML = depts.map(d => {
    const n   = +d.waiting || 0;
    const pct = Math.round((n / max) * 100);
    if (!detailed) return `
      <div class="dept-card">
        <div class="dept-name" style="color:${d.color}">${d.name}</div>
        <div class="dept-count" style="color:${d.color}">${n}</div>
        <div class="dept-stat">patients waiting</div>
        <div class="dept-bar"><div class="dept-bar-fill" style="width:${pct}%;background:${d.color};"></div></div>
      </div>`;
    const load = n===0?'Idle':n<3?'Low':n<6?'Moderate':'High';
    const lc   = n===0?'var(--text-faint)':n<3?'var(--primary)':n<6?'var(--warning)':'var(--danger)';
    const u    = +d.priority_count || 0;
    return `
      <div class="dept-card" style="border-left:3px solid ${d.color}">
        <div class="dept-name">${d.name}</div>
        <div style="display:flex;align-items:baseline;gap:8px;margin:8px 0 4px;">
          <div class="dept-count" style="color:${d.color}">${n}</div>
          <span style="font-size:11.5px;color:${lc};font-weight:600;">${load}</span>
        </div>
        ${u>0?`<div style="font-size:11.5px;color:var(--danger);font-weight:500;">⚠ ${u} priority case${u>1?'s':''}</div>`
             :`<div style="font-size:11.5px;color:var(--text-faint);">No priority cases</div>`}
        <div class="dept-bar" style="margin-top:8px;"><div class="dept-bar-fill" style="width:${pct}%;background:${d.color};"></div></div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">Est. wait: ${n*7} min</div>
      </div>`;
  }).join('');
}

function renderRegBreakdown(depts) {
  const el = document.getElementById('dept-reg-breakdown');
  if (!el) return;
  const sorted = [...depts].filter(d => +d.waiting > 0).sort((a,b) => b.waiting - a.waiting).slice(0,6);
  el.innerHTML = sorted.map(d => `
    <div style="display:flex;align-items:center;gap:8px;padding:5px 0;">
      <div style="width:8px;height:8px;border-radius:50%;background:${d.color};flex-shrink:0;"></div>
      <div style="flex:1;font-size:12.5px;">${d.name}</div>
      <div style="font-size:12px;font-weight:600;color:${d.color};">${d.waiting}</div>
    </div>`).join('') || '<div style="font-size:12.5px;color:var(--text-muted);">No patients yet</div>';
}

// ── Analytics ──────────────────────────────────────────────────
async function loadAnalytics() {
  try {
    const [stats, an] = await Promise.all([
      api('api/stats.php?type=dashboard'),
      api('api/stats.php?type=analytics')
    ]);

    setText('an-reg',   stats.total);
    const comp = stats.total ? Math.round(stats.served / stats.total * 100) : 0;
    setText('an-comp',  comp + '%');
    setText('an-avg',   Math.round(stats.avg_wait) + 'm');
    setText('an-emerg', stats.emergency);

    // Hourly chart
    const hours = {}; for(let h=7;h<=18;h++) hours[h]=0;
    an.hourly.forEach(r => { if(hours[r.hour]!==undefined) hours[r.hour] = +r.count; });
    const maxH = Math.max(...Object.values(hours), 1);
    const chartEl = document.getElementById('hourly-chart');
    const labEl   = document.getElementById('hourly-labels');
    if (chartEl) chartEl.innerHTML = Object.entries(hours).map(([h,n]) => `
      <div class="bar-wrap">
        <div style="font-size:10.5px;color:var(--text-muted);margin-bottom:4px;">${n||''}</div>
        <div class="bar" style="height:${Math.max(4,Math.round(n/maxH*70))}px;background:var(--primary-mid);"></div>
      </div>`).join('');
    if (labEl) labEl.innerHTML = Object.keys(hours).map(h =>
      `<div style="flex:1;font-size:10.5px;color:var(--text-muted);text-align:center;">${h}h</div>`).join('');

    // Priority distribution
    const pd = document.getElementById('priority-dist');
    if (pd) {
      const total  = an.priorities.reduce((s,r) => s + +r.count, 0);
      const byPrio = { Normal:0, Urgent:0, Emergency:0 };
      an.priorities.forEach(r => byPrio[r.priority] = +r.count);
      pd.innerHTML = total === 0 ? emptyState('📊','No data yet') :
        `<div style="display:grid;gap:10px;">
          ${[['Normal','var(--primary)',byPrio.Normal],['Urgent','var(--accent)',byPrio.Urgent],['Emergency','var(--danger)',byPrio.Emergency]].map(([label,color,n]) => `
            <div>
              <div style="display:flex;justify-content:space-between;margin-bottom:4px;font-size:13px;">
                <span style="color:${color};font-weight:500;">${label}</span>
                <span style="color:var(--text-muted);">${n} (${total?Math.round(n/total*100):0}%)</span>
              </div>
              <div style="height:8px;background:var(--border);border-radius:4px;overflow:hidden;">
                <div style="height:100%;width:${total?Math.round(n/total*100):0}%;background:${color};border-radius:4px;transition:width 0.4s;"></div>
              </div>
            </div>`).join('')}
        </div>`;
    }

    // Service log
    const logEl    = document.getElementById('completed-log');
    const logEmpty = document.getElementById('log-empty');
    if (logEl) {
      if (!an.log.length) { logEl.innerHTML=''; if(logEmpty) logEmpty.style.display='block'; }
      else {
        if(logEmpty) logEmpty.style.display='none';
        logEl.innerHTML = an.log.map(p => `
          <tr>
            <td><span class="ticket-num">${p.ticket_number}</span></td>
            <td>${p.first_name} ${p.last_name}</td>
            <td><span class="dept-tag" style="background:${p.bg_color};color:${p.color}">${p.dept_name}</span></td>
            <td>${priorityBadge(p.priority)}</td>
            <td style="font-size:12px;color:var(--text-muted);">${fmtTime(p.created_at)}</td>
            <td style="font-size:12px;color:var(--text-muted);">${p.service_mins || '—'} min</td>
            <td><span class="badge badge-green">✓ Served</span></td>
          </tr>`).join('');
      }
    }
  } catch(e) { /* handled */ }
}

// ── Register Patient ───────────────────────────────────────────
async function registerPatient() {
  const fn   = document.getElementById('f-fname')?.value.trim();
  const ln   = document.getElementById('f-lname')?.value.trim();
  const dept = document.getElementById('f-dept')?.value;
  if (!fn || !ln || !dept) { showNotif('Please fill in required fields (Name + Department)', 'error'); return; }

  try {
    const p = await api('api/register.php', {
      method: 'POST',
      body: JSON.stringify({
        first_name:    fn,
        last_name:     ln,
        age:           document.getElementById('f-age')?.value || '',
        gender:        document.getElementById('f-gender')?.value || '',
        phone:         document.getElementById('f-phone')?.value.trim() || '',
        national_id:   document.getElementById('f-id')?.value.trim() || '',
        department_id: dept,
        priority:      selectedPriority,
        complaint:     document.getElementById('f-complaint')?.value.trim() || '',
      })
    });
    showTicket(p);
    clearForm();
    loadDashboard();
    showNotif('✓ Ticket generated: ' + p.ticket_number);
  } catch(e) { /* handled */ }
}

function selectPriority(el, val) {
  selectedPriority = val;
  document.querySelectorAll('.priority-opt').forEach(o => {
    o.className = 'priority-opt';
    if (o.dataset.val === val) o.classList.add('sel-' + val.toLowerCase());
  });
}

function clearForm() {
  ['f-fname','f-lname','f-age','f-phone','f-id','f-complaint'].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = '';
  });
  const g = document.getElementById('f-gender'); if(g) g.value='';
  const d = document.getElementById('f-dept');   if(d) d.value='';
  selectedPriority = 'Normal';
  document.querySelectorAll('.priority-opt').forEach(o => o.className = 'priority-opt');
}

// ── Ticket Modal ───────────────────────────────────────────────
function showTicket(p) {
  setText('t-num',      p.ticket_number);
  setText('t-name',     p.first_name + ' ' + p.last_name);
  setText('t-dept',     p.dept_name);
  setText('t-priority', p.priority);
  setText('t-ahead',    p.ahead);
  setText('t-wait',     p.wait_mins + ' mins (est.)');
  setText('t-time',     fmtTime(p.created_at));
  const badge = document.getElementById('t-dept-badge');
  if (badge) { badge.textContent = p.dept_name; badge.style.background = p.color || 'var(--primary)'; }
  document.getElementById('ticket-modal').style.display = 'flex';
}
function closeTicket() { document.getElementById('ticket-modal').style.display = 'none'; }

// ── Users ──────────────────────────────────────────────────────
async function loadUsers() {
  try {
    const users = await api('api/users.php');
    const tbody = document.getElementById('users-tbody');
    if (!tbody) return;
    tbody.innerHTML = users.map(u => `
      <tr>
        <td><div style="font-weight:500;">${u.full_name}</div></td>
        <td style="font-family:var(--mono);font-size:12px;">${u.username}</td>
        <td style="font-size:12.5px;color:var(--text-muted);">${u.email}</td>
        <td>${roleBadge(u.role)}</td>
        <td style="font-size:12.5px;">${u.department || '—'}</td>
        <td>${u.is_active ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-gray">Inactive</span>'}</td>
        <td style="font-size:12px;color:var(--text-muted);">${u.last_login ? fmtTime(u.last_login) : 'Never'}</td>
        <td>
          <button class="action-btn call" onclick="editUser(${u.id})">Edit</button>
          ${u.is_active ? `<button class="action-btn skip" onclick="deactivateUser(${u.id})">Disable</button>` : ''}
        </td>
      </tr>`).join('');
  } catch(e) { /* handled */ }
}

function openUserModal(userId) {
  editingUserId = userId || null;
  setText('user-modal-title', userId ? 'Edit User' : 'Add User');
  if (!userId) {
    ['um-name','um-username','um-email','um-password'].forEach(id => {
      const el = document.getElementById(id); if(el) el.value = '';
    });
  }
  const modal = document.getElementById('user-modal');
  if (modal) modal.style.display = 'flex';
}

function closeUserModal() {
  const modal = document.getElementById('user-modal');
  if (modal) modal.style.display = 'none';
  editingUserId = null;
}

async function editUser(id) {
  try {
    const u = await api('api/users.php?id=' + id);
    document.getElementById('um-name').value     = u.full_name;
    document.getElementById('um-username').value = u.username;
    document.getElementById('um-email').value    = u.email;
    document.getElementById('um-password').value = '';
    document.getElementById('um-role').value     = u.role_id;
    document.getElementById('um-dept').value     = '';
    openUserModal(id);
  } catch(e) { /* handled */ }
}

async function saveUser() {
  const body = {
    full_name:  document.getElementById('um-name')?.value.trim(),
    username:   document.getElementById('um-username')?.value.trim(),
    email:      document.getElementById('um-email')?.value.trim(),
    password:   document.getElementById('um-password')?.value,
    role_id:    document.getElementById('um-role')?.value,
    department: document.getElementById('um-dept')?.value || '',
  };
  try {
    if (editingUserId) {
      await api('api/users.php?id=' + editingUserId, { method:'PUT', body: JSON.stringify(body) });
      showNotif('✓ User updated');
    } else {
      await api('api/users.php', { method:'POST', body: JSON.stringify(body) });
      showNotif('✓ User created');
    }
    closeUserModal();
    loadUsers();
  } catch(e) { /* handled */ }
}

async function deactivateUser(id) {
  if (!confirm('Disable this user?')) return;
  try {
    await api('api/users.php?id=' + id, { method:'DELETE' });
    showNotif('User disabled');
    loadUsers();
  } catch(e) { /* handled */ }
}

// ── Notification ───────────────────────────────────────────────
function showNotif(msg, type = 'success') {
  const el = document.getElementById('notif');
  if (!el) return;
  el.textContent = msg;
  el.style.background = type==='error'?'var(--danger)':type==='info'?'var(--info)':'var(--primary)';
  el.style.display = 'block';
  clearTimeout(el._t);
  el._t = setTimeout(() => el.style.display = 'none', 3200);
}

// ── Badge helpers ──────────────────────────────────────────────
function priorityBadge(p) {
  if (p==='Emergency') return '<span class="badge badge-red">🔴 Emergency</span>';
  if (p==='Urgent')    return '<span class="badge badge-orange">🟠 Urgent</span>';
  return '<span class="badge badge-green">🟢 Normal</span>';
}
function statusBadge(s) {
  if (s==='Called') return '<span class="badge badge-blue">📢 Called</span>';
  if (s==='Served') return '<span class="badge badge-green">✓ Served</span>';
  if (s==='Cancelled') return '<span class="badge badge-gray">✗ Cancelled</span>';
  return '<span class="badge badge-gray">⏳ Waiting</span>';
}
function roleBadge(role) {
  const map = { admin:'badge-red', receptionist:'badge-blue', doctor:'badge-green', pharmacist:'badge-orange' };
  return `<span class="badge ${map[role]||'badge-gray'}">${role}</span>`;
}

// ── Utilities ──────────────────────────────────────────────────
function setText(id, val) {
  const el = document.getElementById(id); if (el) el.textContent = val;
}
function emptyState(icon, msg) {
  return `<div class="empty-state"><div class="ei">${icon}</div><p>${msg}</p></div>`;
}
function fmtTime(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleTimeString('en-KE', {hour:'2-digit', minute:'2-digit'});
}
