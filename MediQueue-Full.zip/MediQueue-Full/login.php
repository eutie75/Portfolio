<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>MediQueue — Login</title>
  <link rel="stylesheet" href="css/style.css"/>
  <style>
    body { display:flex; align-items:center; justify-content:center; min-height:100vh; background:var(--bg); }
    .login-wrap { width:100%; max-width:420px; padding:24px; }
    .login-card { background:#fff; border-radius:14px; padding:36px 32px; box-shadow:0 4px 24px rgba(0,0,0,0.10); border:1px solid var(--border); }
    .login-logo { text-align:center; margin-bottom:28px; }
    .login-logo .icon { font-size:40px; margin-bottom:6px; }
    .login-logo h1 { font-size:22px; font-weight:700; color:var(--primary); letter-spacing:-0.5px; }
    .login-logo p { font-size:13px; color:var(--text-muted); margin-top:2px; }
    .error-box { background:var(--danger-light); color:var(--danger); border:1px solid #fca5a5; border-radius:8px; padding:10px 14px; font-size:13px; margin-bottom:16px; display:none; }
    .role-hint { background:var(--primary-light); border-radius:8px; padding:12px 14px; font-size:12px; color:var(--primary); margin-top:20px; }
    .role-hint strong { display:block; margin-bottom:6px; font-size:12.5px; }
    .role-hint table { width:100%; border-collapse:collapse; }
    .role-hint td { padding:2px 6px; }
    .role-hint td:first-child { font-weight:500; width:130px; }
    .divider { border:none; border-top:1px solid var(--border); margin:20px 0; }
    .form-group { margin-bottom:14px; }
  </style>
</head>
<body>
<?php
require_once 'includes/auth.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($username && $password) {
        $user = login($username, $password);
        if ($user) {
            header('Location: index.php');
            exit;
        } else {
            $error = 'Invalid username or password.';
        }
    } else {
        $error = 'Please enter both username and password.';
    }
}

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}
?>

<div class="login-wrap">
  <div class="login-card">
    <div class="login-logo">
      <div class="icon">🏥</div>
      <h1>MediQueue</h1>
      <p>Hospital Ticketing Management System</p>
    </div>

    <?php if ($error): ?>
    <div class="error-box" style="display:block"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
      <div class="form-group">
        <label>Username or Email</label>
        <input type="text" name="username" placeholder="e.g. admin" required autofocus
               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:10px;">
        Sign In →
      </button>
    </form>

    <hr class="divider">

    <div class="role-hint">
      <strong>Demo credentials (password: <code>password</code>)</strong>
      <table>
        <tr><td>admin</td><td>System Administrator</td></tr>
        <tr><td>jane</td><td>Receptionist</td></tr>
        <tr><td>dr_kamau</td><td>Doctor</td></tr>
      </table>
    </div>
  </div>
</div>
</body>
</html>
