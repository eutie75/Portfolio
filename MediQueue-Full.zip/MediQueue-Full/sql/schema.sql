-- ============================================================
-- MediQueue — Hospital Ticketing Management System
-- sql/schema.sql — Full Database Schema
-- Run this file once to set up the database
-- ============================================================

CREATE DATABASE IF NOT EXISTS mediqueue CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mediqueue;

-- ── Users & Roles ────────────────────────────────────────────
CREATE TABLE roles (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(50) NOT NULL UNIQUE,   -- admin, receptionist, doctor, pharmacist
    label      VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO roles (name, label) VALUES
    ('admin',        'System Administrator'),
    ('receptionist', 'Receptionist'),
    ('doctor',       'Doctor / Clinician'),
    ('pharmacist',   'Pharmacist / Lab Tech');

CREATE TABLE users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(150) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    username      VARCHAR(80)  NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role_id       INT NOT NULL,
    department    VARCHAR(100) DEFAULT NULL,   -- assigned dept (for doctors)
    is_active     TINYINT(1) DEFAULT 1,
    last_login    TIMESTAMP NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- Default admin — password: Admin@1234
INSERT INTO users (full_name, email, username, password_hash, role_id) VALUES
    ('System Admin',      'admin@mediqueue.local',       'admin',       '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1),
    ('Jane Receptionist', 'jane@mediqueue.local',        'jane',        '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2),
    ('Dr. Kamau Omondi',  'dr.kamau@mediqueue.local',    'dr_kamau',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3),
    ('Dr. Amina Hassan',  'dr.amina@mediqueue.local',    'dr_amina',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3);

-- ── Departments ───────────────────────────────────────────────
CREATE TABLE departments (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100) NOT NULL UNIQUE,
    code       VARCHAR(5)   NOT NULL UNIQUE,  -- prefix for ticket numbers
    color      VARCHAR(10)  DEFAULT '#1a6f5c',
    bg_color   VARCHAR(10)  DEFAULT '#e6f5f1',
    is_active  TINYINT(1)   DEFAULT 1,
    created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO departments (name, code, color, bg_color) VALUES
    ('General OPD',  'G', '#1a6f5c', '#e6f5f1'),
    ('Emergency',    'E', '#e53e3e', '#fff5f5'),
    ('Pediatrics',   'P', '#f97316', '#fff4ed'),
    ('Maternity',    'M', '#d53f8c', '#fdf2f8'),
    ('Orthopedics',  'O', '#2563eb', '#eff6ff'),
    ('Cardiology',   'C', '#e53e3e', '#fff5f5'),
    ('Dermatology',  'D', '#d97706', '#fffbeb'),
    ('Pharmacy',     'PH','#7c3aed', '#f5f3ff'),
    ('Laboratory',   'L', '#0891b2', '#ecfeff'),
    ('Radiology',    'R', '#059669', '#f0fdf4');

-- ── Patients ──────────────────────────────────────────────────
CREATE TABLE patients (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    ticket_number VARCHAR(10)  NOT NULL UNIQUE,
    first_name    VARCHAR(80)  NOT NULL,
    last_name     VARCHAR(80)  NOT NULL,
    age           TINYINT UNSIGNED DEFAULT NULL,
    gender        ENUM('Male','Female','Other','Prefer not to say') DEFAULT NULL,
    phone         VARCHAR(20)  DEFAULT NULL,
    national_id   VARCHAR(20)  DEFAULT NULL,
    department_id INT          NOT NULL,
    priority      ENUM('Normal','Urgent','Emergency') DEFAULT 'Normal',
    complaint     TEXT         DEFAULT NULL,
    status        ENUM('Waiting','Called','Served','Cancelled') DEFAULT 'Waiting',
    registered_by INT          DEFAULT NULL,   -- user who registered
    called_by     INT          DEFAULT NULL,   -- user who called
    served_by     INT          DEFAULT NULL,   -- user who marked served
    called_at     TIMESTAMP    NULL,
    served_at     TIMESTAMP    NULL,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id),
    FOREIGN KEY (registered_by) REFERENCES users(id),
    FOREIGN KEY (called_by)     REFERENCES users(id),
    FOREIGN KEY (served_by)     REFERENCES users(id)
);

-- ── Activity Log ──────────────────────────────────────────────
CREATE TABLE activity_log (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT          DEFAULT NULL,
    action     VARCHAR(50)  NOT NULL,   -- register, call, serve, login, logout
    patient_id INT          DEFAULT NULL,
    details    TEXT         DEFAULT NULL,
    ip_address VARCHAR(45)  DEFAULT NULL,
    created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)   REFERENCES users(id),
    FOREIGN KEY (patient_id) REFERENCES patients(id)
);

-- ── Sessions (server-side) ────────────────────────────────────
CREATE TABLE user_sessions (
    session_token VARCHAR(128) PRIMARY KEY,
    user_id       INT          NOT NULL,
    ip_address    VARCHAR(45)  DEFAULT NULL,
    user_agent    TEXT         DEFAULT NULL,
    expires_at    TIMESTAMP    NOT NULL,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ── Indexes for performance ───────────────────────────────────
CREATE INDEX idx_patients_status     ON patients(status);
CREATE INDEX idx_patients_department ON patients(department_id);
CREATE INDEX idx_patients_priority   ON patients(priority);
CREATE INDEX idx_patients_created    ON patients(created_at);
CREATE INDEX idx_activity_user       ON activity_log(user_id);
CREATE INDEX idx_activity_created    ON activity_log(created_at);
